# Backlog

## Phase 1 - Define

- [x] Run Research Agent on voice provider options
- [x] Run Research Agent on Twilio WhatsApp requirements
- [x] Run Research Agent on missed-call/home-service buyer pain
- [x] Pick first niche: roofer, HVAC, plumber, or cleaner
- [x] Define exact call script
- [x] Define booking rules
- [x] Define owner notification format
- [x] Define MVP success metric
- [x] Choose WhatsApp vs SMS behavior
- [x] Choose voice provider

## Phase 2 - Build

- [x] Create backend API
- [x] Add file-based lead store
- [x] Add Twilio webhook endpoint
- [x] Add Twilio WhatsApp notification path
- [x] Add SMS fallback notification path
- [x] Add voice-agent webhook endpoint
- [x] Add live Google Calendar booking path
- [ ] Configure Google Calendar credentials
- [x] Add SMS notifications
- [x] Add Render deployment

## Phase 3 - Test

- [x] Run fake Vapi tool call
- [x] Confirm test appointment path is created
- [x] Confirm lead is saved
- [x] Test fallback when no appointment slot exists
- [ ] Confirm customer WhatsApp/SMS sends
- [ ] Confirm owner WhatsApp/SMS sends

## Phase 4 - Sell

- [x] Build demo script
- [x] Build one-page offer
- [x] Make first outreach list template
- [ ] Make first real outreach list
- [ ] Run first pilot
